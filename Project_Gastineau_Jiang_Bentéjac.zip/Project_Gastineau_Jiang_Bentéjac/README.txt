This zip file contains an attempted implementation of a variational 
framework for non-local inpainting.

The test files are located inside the "Testing" directory. This directory
contains:
- a test file for patch match
- a test file for the parallelized version of patch match
- a test file for image update
- a test file for the minimization of energies
- a test file for confidence masks

The whole inpainting program can be launched either through the interface
or the command line.
- For the graphical interface, run "interface" in MATLAB's command window.
- For the command line version, run "VariationalFramework" with the following
parameters:
	- I_init: the image to inpaint
	- Mask: the mask containing the inpainting domain
	- size_patch: the size of the patch that will be used (especially in patch match)
	- nb_level: the number of levels of the multi-scale scheme (1 is the single scale scheme)
	- lambda: the value of the lambda parameter used in the Poisson metric
	- median: 0 or 1, depending on whether you wish to use the median metric
	- average: 0 or 1, depending on whether you wish to use the mean metric
	- poisson: 0 or 1, depending on whether you wish to use the Poisson metric
	N.B: If no similarity metric is chosen , Poisson will be used. If several are chosen, 
	the first one will be selected (the order being: medians, means, Poisson).


In the given state, the framework is not working. Some items composing it seem to be working 
individually, but not as a whole. More details concerning the working/non-working parts can 
be directly found in the report contained in this zip file.

All the code source can be directly found on the project's GitHub repository:
https://github.com/xArchange/VariationalFrameworkInpainting
The GitHub repository also contains alternative versions of functions which we did not 
include to this zip file because they were not working yet and, unlike those you can
find here, have not been extensively tested. In particular, an alternative version of
the image update can be found. Although it applies to grayscale images only, it integrates 
the confidence masks and seems to be making the right computations, although it is very
demanding computationally-wise, and thus very complicated to complete even a single iteration.